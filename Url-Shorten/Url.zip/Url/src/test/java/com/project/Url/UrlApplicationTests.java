package com.project.Url;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class UrlApplicationTests {

	@Test
	void contextLoads() {
	}

}
